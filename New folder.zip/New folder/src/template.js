import React, { Component } from 'react';

class App extends React.Component {
  
    buttonClick(){
      console.log("came here")
      
    }
    
    subComponent() {
      return (<div>Hello World</div>);
    }
    
    render() {
      return ( 
        <div className="patient-container">
            <button onClick={this.buttonClick.bind(this)}>Click me</button>
            {this.subComponent()}
         </div>
       )
    }
}

export default App